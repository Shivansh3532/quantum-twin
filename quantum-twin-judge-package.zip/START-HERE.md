# Quantum Twin — Start Here

Quantum Twin helps developers prepare their code for the quantum-computing threat.

It scans a Node.js project using RSA, creates two independent post-quantum migrations with Codex, tests both, and selects a winner only when the evidence proves it is safe.

## Fastest way to review

1. Open the hosted demo:
   https://quantum-twin.vercel.app/demo?scenario=compatibility

2. Read:
   `Quantum-Twin-Judges-Guide.md`

3. View the real result:
   `sample-report.json`

4. View the test proof:
   `test-results.txt`

## Main idea

**Discover → Explain → Build twice → Prove**

Quantum Twin does not blindly trust one AI-generated security patch. It creates two separate solutions, tests both with the same external checks, and refuses to choose if neither passes.
