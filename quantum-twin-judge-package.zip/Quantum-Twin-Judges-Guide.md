# Quantum Twin — Guide for Judges

Thanks for taking the time to look at this. This one page is meant to get you
from zero to "I understand what it does and I've seen it work" as fast as
possible. Everything here is also in the public repo; this is just the short
version.

## What it does

RSA and ECDSA are not safe against a future quantum computer. NIST has already
standardized the replacements (ML-DSA / FIPS 204, ML-KEM / FIPS 203). The hard
part isn't knowing that — it's changing the crypto in a real codebase without
quietly breaking the services that still verify the old signatures.

Most tools stop at "here is where your crypto is." Quantum Twin goes one step
further. It finds the RSA code, then builds the migration **twice** with Codex,
as two independent strategies:

- **Direct Cutover** — replace RSA with ML-DSA-65 outright.
- **Compatibility Bridge** — ML-DSA-65 plus the RSA path kept alive for frozen
  consumers that can't upgrade yet.

Both candidates get run through the exact same external test harness. A winner
is only picked if it actually passes. If neither passes, the answer is
**NO SAFE WINNER** — the tool refuses to guess. That refusal is the point.

One thing I want to be clear about: GPT-5.6 and Codex write the code and explain
the evidence, but they do **not** decide the winner. Plain deterministic
TypeScript owns every gate and the final selection. The AI can't promote a
candidate that failed.

## How to run it (fastest first)

**1. Just look at the evidence — no install, no login, no credits:**
   https://quantum-twin.vercel.app
   It's read-only. Start with `/demo?scenario=compatibility`, then `/support`
   and `/coverage`.

**2. Run the whole thing locally.**
   Windows: double-click `INSTALL-AND-RUN.bat` in the repo root — it installs
   Node 24.18.0, Git and pnpm for you, then launches.
   Any OS, manual:
   ```
   git clone https://github.com/Shivansh3532/quantum-twin.git
   cd quantum-twin
   npx --yes pnpm@11.9.0 install --frozen-lockfile
   npx --yes pnpm@11.9.0 app
   ```
   Sign in to Codex once, with either method — your own account, no key stored:
   ```
   codex login                 # ChatGPT account (free account works)
   codex login --with-api-key  # or an OpenAI API key
   ```

**3. Check my work without spending anything:**
   ```
   npx --yes pnpm@11.9.0 verify-samples   # re-verifies the committed reports
   npx --yes pnpm@11.9.0 test             # 90 tests
   ```

To watch a live run: open `/lab`, paste
`https://github.com/Shivansh3532/quantum-twin-demo-target`, scan it, read the
hash-bound contract, then authorize the tournament.

## The flow

```
  Node.js repo
      |
      v
  [1] Scan            find RSA/ECDSA signing + verification, keys, tests,
      |               and the services that depend on them
      v
  [2] Contract        freeze it into a versioned, hash-bound compatibility
      |               contract that you approve by exact hash
      v
  [3] Build twice     two isolated Codex builders, same contract,
      |   \           independent worktrees, network disabled
      |    \
   Direct   Bridge
      |    /
      v   v
  [4] Prove           the SAME external harness runs against both:
      |               compile, original tests, tamper/wrong-key rejection,
      |               domain separation, compatibility, repeatability, hashes
      v
  [5] Select          deterministic TypeScript picks the winner among the
                      ones that passed — or returns NO SAFE WINNER
```

## Example: in and out

**In:** a small Node CLI that signs release artifacts with `node:crypto` RSA
(`crypto.sign("sha384", bytes, keys.rsaPrivateKey)`).

**Out** (see `sample-report.json` in this package — a real committed report):
- Both findings detected at `lib/release-signer.cjs` lines 4 and 8, 0.98
  confidence.
- Two candidates built. Direct Cutover and Compatibility Bridge.
- Frozen-consumer test in play, so Direct fails that gate and Bridge passes
  everything.
- Result: **Bridge selected.** Run ID `2026-07-19T18-04-56-297Z`, report
  SHA-256 `077f8dfc267bb6f64fcec12b1919eefd6e0fb338e1f0cb6218e405301e93f9e9`.

You can re-verify that exact file yourself:
`npx --yes pnpm@11.9.0 qt verify --report sample-report.json`.

## Test results

`test-results.txt` in this package is the raw output from `pnpm test` on my
machine: **90 tests, all passing**, across 8 files. It includes the real
integration tests that run full tournaments end to end — baseline isolation,
bridge selection for a frozen consumer, ML-KEM envelope migration, a
multi-repository coordinated cutover, the deliberate NO SAFE WINNER case, and a
reviewed local-branch apply. Typecheck and production build are both clean too.

## Notes I'd want a judge to know

- **What's fully supported is deliberately narrow.** Single-repo JS/TS Node.js
  RSA sign/verify to ML-DSA-65, proven on Windows and Ubuntu. I labeled the
  bigger stuff (multi-repo, ML-KEM, Express/Fastify/NestJS/Next.js, workspaces)
  **experimental** because it has real local proof but not full cross-platform
  evidence yet. TLS/JWT/KMS/HSM and non-Node languages are discovery-only. I'd
  rather under-claim than have you find a hole.
- **No credentials needed to grade it.** The hosted site needs nothing. The
  local tournament uses your own `codex login`. The app never has an API-key
  field and never stores anything — Codex keeps the session in `~/.codex`.
- **The reports are tamper-evident.** Every report is content-hashed. `verify`
  fails on altered hashes, bad diffs, invalid selection, missing test passes,
  or leaked absolute paths / secrets.
- Built with Codex and GPT-5.6, reviewed by me. `/feedback` Codex Session ID:
  `019f774d-0364-76a3-bd72-cb806fe0109a`.

Repo: https://github.com/Shivansh3532/quantum-twin
